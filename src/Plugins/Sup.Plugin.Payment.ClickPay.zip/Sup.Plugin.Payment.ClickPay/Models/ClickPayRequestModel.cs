﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Web.Framework.Models;

namespace Nop.Plugin.Payment.ClickPay.Models
{
    public class ClickPayRequestModel 
    {
        public string ProfileId { get; set; }
        public string TranType { get; set; }
        public string TranClass { get; set; }
        public string CartDescription { get; set; }
        public string CartId { get; set; }
        public string CartCurrency { get; set; }
        public decimal CartAmount { get; set; }
        public string Callback { get; set; }
        public string ReturnUrl { get; set; }
    }
}
