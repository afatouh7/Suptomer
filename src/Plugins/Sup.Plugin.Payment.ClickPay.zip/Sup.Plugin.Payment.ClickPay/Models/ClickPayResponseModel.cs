﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Payment.ClickPay.Models
{
    public class ClickPayResponseModel
    {
        public string TranRef { get; set; }
        public string CartId { get; set; }
        public string CartDescription { get; set; }
        public string CartCurrency { get; set; }
        public string CartAmount { get; set; }
        public CustomerDetails CustomerDetails { get; set; }
        public PaymentResult PaymentResult { get; set; }
        public PaymentInfo PaymentInfo { get; set; }
    }
}
