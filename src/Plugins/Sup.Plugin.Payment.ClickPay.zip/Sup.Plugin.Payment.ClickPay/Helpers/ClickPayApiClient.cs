﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Nop.Plugin.Payment.ClickPay.Models;

namespace Nop.Plugin.Payment.ClickPay.Helpers
{
    public class ClickPayApiClient
    {
        private readonly HttpClient _httpClient;

        public ClickPayApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _httpClient.BaseAddress = new Uri("https://secure.clickpay.com.sa/");
        }

        public async Task<ClickPayResponseModel> SendPaymentRequestAsync(string serverKey, ClickPayRequestModel requestModel)
        {
            var jsonRequest = JsonConvert.SerializeObject(requestModel);
            var requestContent = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("authorization", serverKey);

            var response = await _httpClient.PostAsync("payment/request", requestContent);

            if (!response.IsSuccessStatusCode)
            {
                // Handle error
                throw new Exception("Failed to send payment request.");
            }

            var jsonResponse = await response.Content.ReadAsStringAsync();
            var responseData = JsonConvert.DeserializeObject<ClickPayResponseModel>(jsonResponse);
            return responseData;
        }
    }
}
