﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework.Mvc.Filters;
using Nop.Web.Framework;
using Nop.Plugin.Payment.ClickPay.Models;
using Nop.Plugin.Payment.ClickPay.Helpers;
using Nop.Services.Security;
using Nop.Core;
using Nop.Web.Framework.Controllers;

namespace Nop.Plugin.Payment.ClickPay.Controllers
{
    [AuthorizeAdmin]
    [Area(AreaNames.Admin)]
    [AutoValidateAntiforgeryToken]
    public class PaymentController: BasePaymentController
    {
        private readonly ClickPayApiClient _clickPayApiClient;
        private readonly IPermissionService _permissionService;
        public PaymentController(ClickPayApiClient clickPayApiClient, IPermissionService permissionService)
        {
            _clickPayApiClient = clickPayApiClient ?? throw new ArgumentNullException(nameof(clickPayApiClient));
            _permissionService = permissionService;
        }

        public async Task<IActionResult> Index()
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ProcessPayment(ClickPayRequestModel requestModel)
        {
            // Set profile ID and server key
            var profileId = "CGKMDG-M9DT6H-NPNK62-967RHV";
            var serverKey = "S6JNLT9RJG-JHM9MKJB6J-B9LBLRZJBW";

            // Send payment request
            var response = await _clickPayApiClient.SendPaymentRequestAsync(serverKey, requestModel);

            // Process response as needed
            return View("PaymentResponse", response);
        }
    }
}

